# Instalação e execução

**Escopo verificado: Windows com Python 3.10+.** As instruções de Linux e macOS abaixo são opcionais e não fazem parte da verificação desta entrega.

## O que é necessário
| Item | Versão | Observação |
|---|---|---|
| Python | 3.10 ou superior | https://www.python.org/downloads/ |
| Flask | 3.1.3 ou superior | instalado pelo `pip` (arquivo `requirements.txt`) |
| Navegador | qualquer atual | Chrome, Edge, Firefox |
| Internet | só na instalação | para baixar Python e Flask |

O banco é o SQLite, que já vem com o Python: **não há nada a instalar para o banco**.

## Jeito fácil (Windows)
Dê dois cliques em **`iniciar.bat`**.
- Se o Python não estiver instalado, ele **pergunta se você quer instalar** (S/N) e usa o `winget` do Windows.
- Se faltar o Flask, o sistema **pergunta se pode instalar** (S/N).
- Depois abre o navegador sozinho. Para encerrar, feche a janela preta.

## Pelo terminal

### Windows (CMD ou PowerShell)
```bat
winget install -e --id Python.Python.3.12
py --version
cd caminho\para\05_Codigo_Fonte
py -m pip install -r requirements.txt
py run.py
```

### Linux (Ubuntu/Debian)
```bash
sudo apt update && sudo apt install -y python3 python3-pip python3-venv
cd caminho/para/05_Codigo_Fonte
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

### macOS
```bash
brew install python
cd caminho/para/05_Codigo_Fonte
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Abra http://127.0.0.1:5000 . **Primeiro acesso:** matrícula `1`, senha `01012000`. O sistema obriga a troca da senha no primeiro login.

## Testes
```bash
python -m unittest discover -v

# cobertura de testes (meta: 80%). Atalho que já salva as evidências em 04_Testes/evidencias:
python gerar_cobertura.py
# ou, manualmente:
pip install coverage
python -m coverage run --source=app -m unittest discover
python -m coverage report -m
```

## Modo opcional de metas
Por padrão o sistema usa as fórmulas do cliente. Para ativar o regime opcional de metas (RN009–RN011):
```bat
set REGIME_METAS=1
py run.py
```
(Linux/macOS: `export REGIME_METAS=1`). Não ative sem o aceite do cliente.

## Problemas comuns
| Sintoma | Solução |
|---|---|
| `python não é reconhecido` | Use `py` no lugar de `python`, ou reinstale marcando **Add Python to PATH**. No Windows, desative o atalho da Microsoft Store em *Configurações > Aplicativos > Aliases de execução*. |
| `externally-managed-environment` (Linux) | Use o ambiente virtual (`python3 -m venv .venv`), como mostrado acima. |
| Porta 5000 em uso | Feche o outro programa ou altere `port=5000` no final do `run.py`. |
| Quero zerar os dados | Feche o sistema e apague a pasta `instance/`. O banco e o admin inicial são recriados na próxima execução. |
